#ifndef I2C_BUS_WRITEBLOCK_H_
#define I2C_BUS_WRITEBLOCK_H_
NAN_METHOD(WriteBlockAsync);
NAN_METHOD(WriteBlockSync);
#endif // I2C_BUS_WRITEBLOCK_H_

