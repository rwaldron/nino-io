#ifndef I2C_BUS_READWORD_H_
#define I2C_BUS_READWORD_H_
NAN_METHOD(ReadWordAsync);
NAN_METHOD(ReadWordSync);
#endif // I2C_BUS_READWORD_H_

