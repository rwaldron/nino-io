#define ERRBUFSZ 64 // boost error_code.cpp uses 64 for buffer size so it should be ok

