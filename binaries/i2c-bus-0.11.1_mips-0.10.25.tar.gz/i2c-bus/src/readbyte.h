#ifndef I2C_BUS_READBYTE_H_
#define I2C_BUS_READBYTE_H_
NAN_METHOD(ReadByteAsync);
NAN_METHOD(ReadByteSync);
#endif // I2C_BUS_READBYTE_H_

