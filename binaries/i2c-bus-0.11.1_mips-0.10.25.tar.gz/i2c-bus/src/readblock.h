#ifndef I2C_BUS_READBLOCK_H_
#define I2C_BUS_READBLOCK_H_
NAN_METHOD(ReadBlockAsync);
NAN_METHOD(ReadBlockSync);
#endif // I2C_BUS_READBLOCK_H_

