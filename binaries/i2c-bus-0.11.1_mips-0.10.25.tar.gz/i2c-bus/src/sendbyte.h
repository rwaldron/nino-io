#ifndef I2C_BUS_SENDBYTE_H_
#define I2C_BUS_SENDBYTE_H_
NAN_METHOD(SendByteAsync);
NAN_METHOD(SendByteSync);
#endif // I2C_BUS_SENDBYTE_H_

