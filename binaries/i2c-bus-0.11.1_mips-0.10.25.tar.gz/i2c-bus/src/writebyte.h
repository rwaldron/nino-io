#ifndef I2C_BUS_WRITEBYTE_H_
#define I2C_BUS_WRITEBYTE_H_
NAN_METHOD(WriteByteAsync);
NAN_METHOD(WriteByteSync);
#endif // I2C_BUS_WRITEBYTE_H_

